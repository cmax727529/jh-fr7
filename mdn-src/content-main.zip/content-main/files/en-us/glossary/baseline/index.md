---
title: Baseline
slug: Glossary/Baseline
page-type: glossary-disambiguation
---

{{GlossarySidebar}}

The term **baseline** can have several meanings depending on the context. It may refer to:

{{GlossaryDisambiguation}}
