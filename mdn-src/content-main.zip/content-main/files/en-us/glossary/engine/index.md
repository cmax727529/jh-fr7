---
title: Engine
slug: Glossary/Engine
page-type: glossary-definition
---

{{GlossarySidebar}}

The term **engine** can have several meanings depending on the context. It may refer to:

{{GlossaryDisambiguation}}
