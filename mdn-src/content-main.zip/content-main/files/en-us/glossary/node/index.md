---
title: Node
slug: Glossary/Node
page-type: glossary-disambiguation
---

{{GlossarySidebar}}

The term **node** can have several meanings depending on the context. It may refer to:

{{GlossaryDisambiguation}}

Another use of the word is when talking about {{Glossary("Node.js")}}
