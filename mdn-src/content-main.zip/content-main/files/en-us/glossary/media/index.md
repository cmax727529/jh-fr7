---
title: Media
slug: Glossary/Media
page-type: glossary-disambiguation
---

{{GlossarySidebar}}

The term **media** is an overloaded one when talking about the web; it takes on different meanings depending on the context.

{{GlossaryDisambiguation}}

## See also

- [Media](https://en.wikipedia.org/wiki/Media) on Wikipedia
