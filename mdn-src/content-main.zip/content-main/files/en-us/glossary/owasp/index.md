---
title: OWASP
slug: Glossary/OWASP
page-type: glossary-definition
---

{{GlossarySidebar}}

**OWASP** (Open Web Application Security Project) is a non-profit organization and worldwide network that works for security in Free Software, especially on the Web.

## See also

- [Official website](https://owasp.org/)
