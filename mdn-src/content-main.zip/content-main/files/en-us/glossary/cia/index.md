---
title: CIA
slug: Glossary/CIA
page-type: glossary-definition
---

{{GlossarySidebar}}

**CIA (Confidentiality, Integrity, Availability)** (also called the CIA triad or AIC triad) is a model that guides an organization's policies for information security.

## See also

- [CIA](https://en.wikipedia.org/wiki/Information_security#Key_concepts) on Wikipedia
