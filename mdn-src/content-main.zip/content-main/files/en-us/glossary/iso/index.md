---
title: ISO
slug: Glossary/ISO
page-type: glossary-definition
---

{{GlossarySidebar}}

**ISO** (International Organization for Standardization) is a global association that develops uniform criteria coordinating the companies in each major industry.

## See also

- [Official website](https://www.iso.org/home.html)
