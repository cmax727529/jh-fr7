---
title: Hypertext
slug: Glossary/Hypertext
page-type: glossary-definition
---

{{GlossarySidebar}}

Hypertext is text that contains links to other texts, as opposed to a single linear flow like in a novel.

The term was coined by Ted Nelson around 1965.

## See also

- [Hypertext](https://en.wikipedia.org/wiki/Hypertext) on Wikipedia
