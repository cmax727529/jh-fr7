---
title: Firefox OS
slug: Glossary/Firefox_OS
page-type: glossary-definition
---

{{GlossarySidebar}}

Firefox OS is a discontinued open source mobile operating system developed by Mozilla. See [Firefox OS](https://en.wikipedia.org/wiki/Firefox_OS) for more details.

Firefox OS was also often called Boot2Gecko before the project had an official name.
